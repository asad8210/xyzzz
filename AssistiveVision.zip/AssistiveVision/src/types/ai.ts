export interface AIResponse {
  text: string;
  success: boolean;
}

export interface Message {
  text: string;
  isUser: boolean;
  timestamp: number;
}