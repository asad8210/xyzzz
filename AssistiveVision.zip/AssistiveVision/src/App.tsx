import React from 'react';
import { Navigation } from './components/Navigation';
import WebcamFeed from './components/WebcamFeed';
import { PersonalAssistant } from './components/PersonalAssistant';
import TextReader from './components/TextReader';
import { Map, Eye, MessageSquare, FileText } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <h1 className="text-5xl font-bold text-center mb-12 text-gray-900">
        Assistive Vision
      </h1>

      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

        {/* Object Detection Section */}
        <section className="bg-white rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 p-8">
          <h2 className="text-2xl font-semibold flex items-center gap-4 mb-6 text-gray-900">
            <Eye className="w-10 h-10 text-green-600 transition-transform duration-200 hover:scale-110" />
            Real World Detection
          </h2>
          <WebcamFeed />
        </section>

        {/* Text Reader Section */}
        <section className="bg-white rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 p-8">
          <h2 className="text-2xl font-semibold flex items-center gap-4 mb-6 text-gray-900">
            <FileText className="w-10 h-10 text-orange-600 transition-transform duration-200 hover:scale-110" />
            Document Reader
          </h2>
          <TextReader />
        </section>

        {/* AI Assistant Section */}
        <section className="bg-white rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 p-8">
          <h2 className="text-2xl font-semibold flex items-center gap-4 mb-6 text-gray-900">
            <MessageSquare className="w-10 h-10 text-purple-600 transition-transform duration-200 hover:scale-110" />
            AI Assistant
          </h2>
          <PersonalAssistant />
        </section>

        {/* Navigation Section */}
        <section className="bg-white rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 p-8">
          <h2 className="text-2xl font-semibold flex items-center gap-4 mb-6 text-gray-900">
            <Map className="w-10 h-10 text-blue-600 transition-transform duration-200 hover:scale-110" />
            Navigation Assistant
          </h2>
          <Navigation />
        </section>
      </div>

      {/* Footer */}
      <footer className="bg-gray-200 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-600">
            © {new Date().getFullYear()} Assistive Vision. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
