import axios from 'axios';

const GEMINI_API_KEY = 'YOUR_GEMINI_API_KEY'; // Replace with your API key
const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';

export const generateResponse = async (prompt: string) => {
  try {
    const response = await axios.post(
      `${API_URL}?key=${GEMINI_API_KEY}`,
      {
        contents: [{ parts: [{ text: prompt }] }]
      }
    );
    return response.data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error('Gemini API error:', error);
    return 'I apologize, but I encountered an error. Please try again.';
  }
};