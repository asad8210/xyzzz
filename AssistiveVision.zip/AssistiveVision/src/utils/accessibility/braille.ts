import braille from 'braille';

export const textToBraille = (text: string): string => {
  return braille.toBraille(text);
};

export const brailleToText = (brailleText: string): string => {
  return braille.toText(brailleText);
};