import axios from 'axios';
import { AIResponse } from '../../types/ai';

const GEMINI_API_KEY = 'AIzaSyDz3npifwfhZe9be2_ApNDs5f12nN8dQu4';
const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';

export const generateAIResponse = async (prompt: string): Promise<AIResponse> => {
  try {
    const response = await axios.post(
      `${API_URL}?key=${GEMINI_API_KEY}`,
      {
        contents: [{ parts: [{ text: prompt }] }]
      }
    );
    return {
      text: response.data.candidates[0].content.parts[0].text,
      success: true
    };
  } catch (error) {
    console.error('Gemini API error:', error);
    return {
      text: 'I apologize, but I encountered an error. Please try again.',
      success: false
    };
  }
};